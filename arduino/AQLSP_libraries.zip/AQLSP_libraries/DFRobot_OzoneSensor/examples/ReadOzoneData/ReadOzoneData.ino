

/* LIBRARIES */
#include "DFRobot_OzoneSensor.h"
#include "Seeed_HM330X.h"
#include "Adafruit_PM25AQI.h"


/* DEFINITIONS */

//DFRobot Ozone Sensor 
#define COLLECT_NUMBER 20  //the collection range is 1-100
#define Ozone_IICAddress OZONE_ADDRESS_3
DFRobot_OzoneSensor Ozone;


//Grove - Laser PM 2.5 
#ifdef ARDUINO_SAMD_VARIANT_COMPLIANCE
#define SERIAL_OUTPUT SerialUSB
#else
#define SERIAL_OUTPUT Serial
#endif
HM330X sensor;
u8 buf[30];

const char *str[] = {
  "sensor num: ",
  "PM1.0 concentration(CF=1,Standard particulate matter,unit:ug/m3): ",
  "PM2.5 concentration(CF=1,Standard particulate matter,unit:ug/m3): ",
  "PM10 concentration(CF=1,Standard particulate matter,unit:ug/m3): ",
  "PM1.0 concentration(Atmospheric environment,unit:ug/m3): ",
  "PM2.5 concentration(Atmospheric environment,unit:ug/m3): ",
  "PM10 concentration(Atmospheric environment,unit:ug/m3): ",
};

HM330XErrorCode print_result(const char *str, u16 value) {
  if (NULL == str)
    return ERROR_PARAM;
  SERIAL_OUTPUT.print(str);
  SERIAL_OUTPUT.println(value);
  return NO_ERROR;
}

/*parse buf with 29 u8-data*/
HM330XErrorCode parse_result(u8 *data) {
  u16 value = 0;
  if (NULL == data)
    return ERROR_PARAM;
  for (int i = 1; i < 8; i++) {
    value = (u16)data[i * 2] << 8 | data[i * 2 + 1];
    print_result(str[i - 1], value);
  }

  return NO_ERROR;
}

HM330XErrorCode parse_result_value(u8 *data) {
  if (NULL == data)
    return ERROR_PARAM;
  for (int i = 0; i < 28; i++) {
    SERIAL_OUTPUT.print(data[i], HEX);
    SERIAL_OUTPUT.print("  ");
    if ((0 == (i) % 5) || (0 == i)) {
      SERIAL_OUTPUT.println(" ");
    }
  }
  u8 sum = 0;
  for (int i = 0; i < 28; i++) {
    sum += data[i];
  }
  if (sum != data[28]) {
    SERIAL_OUTPUT.println("wrong checkSum!!!!");
  }
  SERIAL_OUTPUT.println(" ");
  SERIAL_OUTPUT.println(" ");
  return NO_ERROR;
}


//ADAFruit PM 2.5
Adafruit_PM25AQI aqi = Adafruit_PM25AQI();


//Loop Conditions Initialization
unsigned long prev_timestep = 0;
int interval = 15000;


void setup() {
  Serial.begin(115200);

 //DFRobot Ozone Sensor Set Up
  while (!Ozone.begin(Ozone_IICAddress)) {
    Serial.println("I2c device number error !");
    delay(1000);
  }
Ozone.setModes(MEASURE_MODE_PASSIVE);

//Grove - Laser PM2.5 Sensor Set Up
  //SERIAL_OUTPUT.println("Serial start: PM 2.5");
  if (sensor.init()) {
    SERIAL_OUTPUT.println("HM330X init failed!!!");
    while (1);
  }
  //Serial.println("I2c connect success !");
  
//ADAFruit PM 2.5 Set Up
 Serial.println("Adafruit PMSA003I Air Quality Sensor");
 // 3 options for connectivity
  if (! aqi.begin_I2C()) {      // connect to the sensor over I2C
  //if (! aqi.begin_UART(&Serial1)) { // connect to the sensor over hardware serial
  //if (! aqi.begin_UART(&pmSerial)) { // connect to the sensor over software serial 
    Serial.println("Could not find PM 2.5 sensor!");
    while (1) delay(10);
  }
 // Serial.println("PM25 found!");
}

void DFRobot_Ozone() {
int16_t ozoneConcentration = Ozone.readOzoneData(COLLECT_NUMBER);
    Serial.print("Ozone concentration is ");
    Serial.print(ozoneConcentration);
    Serial.println(" PPB.");
}

void Grove_PM25() {
if (sensor.read_sensor_value(buf, 29)) {
      SERIAL_OUTPUT.println("HM330X read result failed!!!");
    }
    parse_result_value(buf);
    parse_result(buf);
    SERIAL_OUTPUT.println(" ");
    SERIAL_OUTPUT.println(" ");
    SERIAL_OUTPUT.println(" ");
}

void ADAFruit_PM25(){
PM25_AQI_Data data;
  
  if (! aqi.read(&data)) {
    Serial.println("Could not read from AQI");
    delay(500);  // try again in a bit!
    return;
  }
  Serial.println("AQI reading success");

  Serial.println();
  Serial.println(F("---------------------------------------"));
  Serial.println(F("Concentration Units (standard)"));
  Serial.println(F("---------------------------------------"));
  Serial.print(F("PM 1.0: ")); Serial.print(data.pm10_standard);
  Serial.print(F("\t\tPM 2.5: ")); Serial.print(data.pm25_standard);
  Serial.print(F("\t\tPM 10: ")); Serial.println(data.pm100_standard);
  Serial.println(F("Concentration Units (environmental)"));
  Serial.println(F("---------------------------------------"));
  Serial.print(F("PM 1.0: ")); Serial.print(data.pm10_env);
  Serial.print(F("\t\tPM 2.5: ")); Serial.print(data.pm25_env);
  Serial.print(F("\t\tPM 10: ")); Serial.println(data.pm100_env);
  Serial.println(F("---------------------------------------"));
  Serial.print(F("Particles > 0.3um / 0.1L air:")); Serial.println(data.particles_03um);
  Serial.print(F("Particles > 0.5um / 0.1L air:")); Serial.println(data.particles_05um);
  Serial.print(F("Particles > 1.0um / 0.1L air:")); Serial.println(data.particles_10um);
  Serial.print(F("Particles > 2.5um / 0.1L air:")); Serial.println(data.particles_25um);
  Serial.print(F("Particles > 5.0um / 0.1L air:")); Serial.println(data.particles_50um);
  Serial.print(F("Particles > 10 um / 0.1L air:")); Serial.println(data.particles_100um);
  Serial.println(F("---------------------------------------"));
}


void loop() {
  unsigned long timestep = millis();
   if (timestep - prev_timestep >= interval) {
    prev_timestep = timestep;
    DFRobot_Ozone();
    Grove_PM25();
    ADAFruit_PM25();
  }
}